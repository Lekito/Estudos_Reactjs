import React from 'react';
import './App.css';
import PaginaInicial from './componentes/PaginaInicial';

function App() {
  return (
    <div className="App">
      <PaginaInicial />
    </div>
  );
}

export default App;
